from kyt import *

# // DELETE IP
@bot.on(events.CallbackQuery(data=b'deleteip'))
async def deleteipp(event):
	async def deleteipp_(event):
		async with bot.conversation(chat) as pw:
			await event.respond("**Input IP VPS:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		cmd = f'printf "%s\n" "{pw}" | del-ip-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Not Exist**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━**
 **⟨ SUCCESS DELETE IP ADDRESS ⟩**
**━━━━━━━━━━━━━━━━━━━**
 `IP VPS   :` `{pw}`
**━━━━━━━━━━━━━━━━━━━**
**» 🤖@masansor**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await deleteipp_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# // ADD IP
@bot.on(events.CallbackQuery(data=b'resgissc'))
async def registersc(event):
	async def registersc_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**IP VPS:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")],
[Button.inline(" 90 Day ","90"),
Button.inline(" Lifetime ","360")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{pw}" "{user}" "{exp}" | add-ip-bot'
		try:
			msg = f"""
`🧿───────────────────🧿`
**REGRIST AUTOSCRIPT PREMIUM**
`🧿───────────────────🧿`
` ID   : ``{user}`
` Ip   : ``{pw}`
` Exp  : ``{exp} Days`
`🧿───────────────────🧿`
Automatic Notification from Github
`🧿───────────────────🧿`
** Klik To Create Link Instalaion**
https://pastebin.com/raw/uxbRqC1K
"""
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(msg)
		else:
			await event.respond("**Kusus Reseler Masee !!!**")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await registersc_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'regis'))
async def menu(event):
	inline = [
[Button.inline(" ADD IP ","resgissc"),
Button.inline(" DELETE IP ","deleteip")],
[Button.inline(" RENEW IP ","renewip"),
Button.url(" JOIN ","https://t.me/masansor")],
[Button.inline("‹ BACK ›","menu")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' curl -sS https://raw.githubusercontent.com/angga2103/permission/main/ipmini | grep "###" | wc -l'
		usersc = subprocess.check_output(sh, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

		msg = f"""
🧿───────────────────🧿
   **REGISTRASI IP AUTO SCRIPT**
🧿───────────────────🧿
Hi {sender.first_name}
`Total Online  :` `{usersc.strip()}`
`Autoscript By :` @masansor
🧿───────────────────🧿

"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)

